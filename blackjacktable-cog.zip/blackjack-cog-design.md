# Blackjack Table — Custom Red Cog Design

## Yes, this is possible — and it's the right call

A Red cog is just a Python package that hooks `redbot.core.commands` and `redbot.core.Config`. Nothing about "multiplayer table with buttons" is off-limits — Red 3.5+ runs on discord.py 2.x, which is the same library both reference bots' features map onto: `discord.ui.View` (buttons) and `discord.ui.Button` are first-class, no reaction-based fallback needed. Building this as a cog rather than a 5th standalone bot means it shares your `evacnet`/bank/Config plumbing instead of adding another container, another bot token, another set of secrets, and another update cadence.

**What you take from each reference project** (concept only — not their code, since licenses differ and the code itself isn't the hard part):

- From **thiagoravelli's bot**: the *table-as-a-session* model — a lobby that opens, collects players, locks, deals, and runs a shared round with turn order and a dealer that acts last. This becomes your `Table` class.
- From **zwolsman's bot**: the *multi-hand-per-player* concept — a player can end up with more than one hand mid-round (relevant once splits land in v2), so hands are modeled as objects owned by a player, not the player having exactly one hand. Building this in from day one avoids a rewrite later even though split isn't in v1.

Everything else — Red command wiring, bank API calls, Config schema, the button View, embed rendering — is new, built for how *your* bot is set up.

---

## Locked decisions

| # | Question | Decision |
|---|---|---|
| 1 | Restart durability | **Skipped.** Bot rarely restarts — in-memory round state, no Config/Redis persistence. A restart mid-round loses that round; accepted risk. |
| 2 | Tables per channel | **One at a time**, hardcoded to a single channel: `1530348323330986005`. |
| 3 | Solo play | **Allowed.** `MIN_SEATS = 1` — a lone player can sit down and play straight against the dealer. |
| 4 | Ruleset depth | **Real casino** rules for v1: 6-deck shoe (not single deck), dealer stands on all 17s, blackjack pays 3:2. Splits/insurance/surrender still deferred to v2, but the shoe and payout math are full-fidelity now, not a simplified placeholder. |
| 5 | Kill switch | **Command-based toggle**, admin-only — `.blackjackset enabled true/false` gates whether `.blackjack table` can be run at all. Building this into `blackjacktable.py` next. |
| 6 | Spectator visibility | **Public.** Anyone in the channel sees the live table embed as it updates. |
| 7 | Player leaves mid-hand | **Recommended default**: forced stand on their current hand, removed from future rounds at that table, no refund of an already-placed bet. |
| 8 | Balance display | **Public.** Seated players' bank balances are visible on the table embed. |

---

## Cog layout

Matches the pattern of your existing custom cogs (`duel`, `gamble`, `heist`, `rolewipe`) in `~/evac-cogs`:

```
blackjacktable/
├── __init__.py          # setup() entrypoint — DONE (this was the missing piece causing the load error)
├── blackjacktable.py     # cog class, command group, listeners — DONE (minimal: kill switch + placeholder table cmd)
├── engine.py              # pure game logic: deck, hand values, dealer AI — DONE, tested
├── table.py               # Table class: lobby state, seat management, round loop — NOT YET WRITTEN
├── views.py                # discord.ui.View/Button subclasses (JoinView, ActionView) — NOT YET WRITTEN
├── models.py               # Hand, Seat, Card, Table dataclasses — DONE
├── constants.py             # payouts, timers, table size limits, channel lock — DONE
├── test_engine.py            # pytest suite for engine.py — DONE, 23/23 passing
└── info.json                # Red cog metadata — DONE
```

`engine.py` having zero discord.py imports matters: you can unit-test blackjack math (dealer soft-17 behavior, bust detection, blackjack payout) with plain `pytest`, no bot instance required — worth doing given money is on the line. **This step is done** — see Build Progress below.

---

## Data model (as implemented in `models.py`)

```python
class Suit(Enum): CLUBS, DIAMONDS, HEARTS, SPADES
class Rank(Enum): TWO..TEN, JACK, QUEEN, KING, ACE

@dataclass(frozen=True)
class Card:
    rank: Rank
    suit: Suit

@dataclass
class Hand:
    cards: list[Card]
    bet: int
    status: Literal["playing", "stood", "bust", "blackjack", "surrendered"]
    # split_from reserved for v2, deliberately absent now

@dataclass
class Seat:
    member_id: int          # plain Discord user ID, not a discord.Member — keeps this testable
    display_name: str
    hands: list[Hand]        # len 1 in v1, >1 once splits ship

TableState = Literal["lobby", "betting", "dealing", "player_turns", "dealer_turn", "settling", "closed"]
```

`Table` itself (the stateful class that owns seats, the shoe, current turn index, and the live Discord message) is `table.py` — next build step, not yet written.

State lives **in memory**, keyed by `channel_id` (though with the single-channel lock in place, there's really just one table slot for now), inside the cog instance. Not in `Config` — consistent with the "skip restart durability" decision above.

---

## Round flow (state machine)

1. **Lobby** — `.blackjack table [min_bet] [max_bet]` posts an embed with a **Join** button and a **Start Now** button (host-only). Auto-starts after a configurable timeout (default 45s) or when max seats (7) fill. Blocked entirely if the admin toggle is off.
2. **Betting** — on start, each seated player gets a prompt to set their bet within the table's min/max. Players who don't respond within the bet timeout are auto-removed from the round (not the table — they can rebet next round).
3. **Dealing** — engine deals 2 cards to each seat from the shoe, 2 to dealer (one face down). Embed updates showing all player hands face-up, dealer showing one card.
4. **Player turns** — sequential, in join order. Active player gets Hit / Stand / Double buttons (interaction check rejects presses from anyone else). Table embed re-renders after every action. Turn auto-stands on timeout (default 30s).
5. **Dealer turn** — reveal hole card, draw per the stand-on-17 rule, using `play_dealer()` from `engine.py`. Skipped entirely if every player hand already busted.
6. **Settling** — `settle_hand()` resolves each hand against the final dealer hand, bank payouts via Red's bank API, results embed posted, table loops back to Lobby or closes based on host choice.

---

## Discord UI

- One message per table, continuously edited (not re-sent).
- Embed shows: table state, seat list with avatars/names, each player's hand + running total, bet amounts, dealer's visible card(s), and (per decision #8) each seated player's current balance.
- `JoinView`: Join / Leave buttons, active only during Lobby.
- `ActionView`: Hit / Stand / Double, active only for the current player, enforced both visually and in the interaction check.

---

## Red integration specifics

- **Bank API**: `bank.withdraw_credits()` at bet-lock, `bank.deposit_credits()` at settlement — same shared ledger as `economy`, `casino`, `gamble`, `heist`, `shop`.
- **Config**: guild-scoped — `enabled` (the kill switch from decision #5), default min/max bet, timeouts. Channel is hardcoded via `constants.DEFAULT_CHANNEL_ID` rather than Config for now, since there's only ever the one channel.
- **Kill switch command**: `.blackjackset enabled <true|false>` — admin/mod-permission gated, flips the Config flag `blackjacktable.enabled` that `.blackjack table` checks before allowing a new lobby to open. An in-progress round finishes normally even if toggled off mid-round (doesn't yank the rug on seated players).
- **Permissions**: `@commands.guild_only()`, cooldown on `.blackjack table` itself, hardcoded channel check (command silently no-ops or errors politely outside channel `1530348323330986005`).
- **Cog conflicts**: `duel`, `gamble`, `heist` all touch the same bank — Red's bank API is atomic per call, so no race risk; worth a smoke test once built regardless.

---

## v1 ruleset (real casino, per decision #4)

- 6-deck shoe, reshuffled fresh each round (no cut-card/penetration tracking yet — v2 candidate).
- Hit / Stand / Double down only. No split, no insurance, no surrender in v1.
- Dealer stands on all 17s (hard and soft).
- Blackjack (natural 21 on first two cards) pays 3:2; regular win pays 1:1; push returns bet; dealer blackjack beats any non-blackjack player hand (including a 21 reached via hit — verified in `test_settle_dealer_blackjack_beats_player_21_via_hit`).
- Double down: exactly one additional card, bet doubles, only on a fresh two-card hand.

**v2 candidates**: split (up to 3x, no resplit-aces), insurance, configurable soft-17, surrender, side bets, shoe penetration/cut-card, restart-safe persistence if that ever becomes worth the effort.

---

## Build progress

1. ✅ **`engine.py` + `test_engine.py`** — shoe, hand scoring, dealer AI, payout math. 23/23 tests passing (`hand_value`, blackjack detection, dealer stand/hit, all six settlement outcomes, double-down eligibility, shoe exhaustion). Zero discord.py dependency, as designed.
2. ⬜ **`table.py`** — `Table` class wrapping the state machine (lobby → betting → dealing → player_turns → dealer_turn → settling), driven by the enums/dataclasses in `models.py` and the functions in `engine.py`. Next step.
3. ⬜ **`views.py`** — Join/Action buttons wired to `table.py`.
4. ✅ **`blackjacktable.py`** — minimal but real Red cog: `.blackjack table` (enforces the channel lock and the enabled/disabled kill switch, otherwise a placeholder — the actual lobby/gameplay wiring happens once `table.py`/`views.py` exist), `.blackjackset enabled/minbet/maxbet/settings`, guild-scoped Config schema, cooldown, admin permission gating. **This is what fixes the "does not have a setup function" load error** — `__init__.py` now has a real `setup()` that registers this cog.
5. ✅ **`info.json`** — Red cog metadata.
6. ⬜ Deploy through your existing flow: commit to `evac-cogs` → push → `.repo update evac-cogs` → `.cog update` → `.load blackjacktable`. (You can also just drop the files in directly and `.load` for now, since you're testing pre-repo.)
7. ⬜ Soak-test in-channel with small bets before treating it as production-ready — moot until `table.py`/`views.py` land, since `.blackjack table` doesn't deal a hand yet.

**Load-error note**: the exception you hit (`does not have a setup function`) was expected — the previous drop only had `engine.py`/`models.py`/`constants.py`, none of which are a Discord cog. `blackjacktable.py` + the updated `__init__.py` are the actual loadable cog; the game itself still isn't playable until steps 2-3 above land, but the cog now loads cleanly, the channel lock and kill switch are live and testable today.

All files were delivered to you as a zip in this conversation — drop `blackjacktable/` straight into `~/evac-cogs/`.
